Hello,
To access this application, first you need to download some modules listed below using the commands which is given corresponding to the
module in the command prompt. If you have any trouble downloading the modules, refer to some videos which are available in the internet.
The modules used in the program:
1. Tkinter module - "pip install tk"
2. datetime - "pip install datetime"
After downloading the above modules. Open Main.py and Run it.
Username and password for accessing the Admin rights are ADMIN and 1234 respectively
NOTE: Username and password both are case sensitive
If you still have problem in running the program, contact me through my email id : bhavesh71.logu@gmail.com
Thank you